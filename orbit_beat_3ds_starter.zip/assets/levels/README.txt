Put original level files here in a future milestone.
