#include <3ds.h>
#include <cstdio>
#include <cmath>

namespace {
    constexpr int BPM = 120;
    constexpr u64 BEAT_US = 60000000ULL / BPM;
    constexpr u64 HIT_WINDOW_US = 180000ULL;

    u64 nextBeat = 0;
    int beatNumber = 1;
    int score = 0;
    int combo = 0;
    int lastDeltaMs = 0;
    const char* message = "Press A on the beat!";
    bool hasResult = false;
    PrintConsole topScreen;
    PrintConsole bottomScreen;

    void resetBeatClock() {
        nextBeat = osGetTime() * 1000ULL + BEAT_US;
        beatNumber = 1;
    }

    void attemptHit() {
        const u64 now = osGetTime() * 1000ULL;
        const s64 delta = static_cast<s64>(now) - static_cast<s64>(nextBeat);
        const u64 absDelta = static_cast<u64>(delta < 0 ? -delta : delta);
        lastDeltaMs = static_cast<int>(delta / 1000);

        if (absDelta <= HIT_WINDOW_US) {
            score += 100;
            combo++;
            message = "PERFECT! +100";
        } else {
            combo = 0;
            message = "MISS - try the next beat";
        }
        hasResult = true;
        nextBeat += BEAT_US;
        beatNumber++;
    }
}

int main(int argc, char* argv[]) {
    gfxInitDefault();
    consoleInit(GFX_TOP, &topScreen);
    consoleInit(GFX_BOTTOM, &bottomScreen);
    resetBeatClock();

    while (aptMainLoop()) {
        hidScanInput();
        const u32 down = hidKeysDown();

        if (down & KEY_START) break;
        if (down & KEY_A) attemptHit();

        const u64 now = osGetTime() * 1000ULL;
        if (now > nextBeat + HIT_WINDOW_US) {
            nextBeat += BEAT_US;
            beatNumber++;
            combo = 0;
            message = "Beat passed — press A on the next one";
            hasResult = true;
        }

        consoleSelect(&topScreen);
        consoleClear();
        printf("ORBIT BEAT\n");
        printf("A tiny original rhythm-game prototype\n\n");
        printf("Tempo: %d BPM\n", BPM);
        printf("Beat:  %d\n", beatNumber);
        printf("Score: %d\n", score);
        printf("Combo: %d\n\n", combo);
        printf("%s\n", message);
        if (hasResult) printf("Timing offset: %d ms\n", lastDeltaMs);
        printf("\nSTART: exit");

        consoleSelect(&bottomScreen);
        consoleClear();
        printf("PROJECT STATUS\n\n");
        printf("This is an early C++ test.\n");
        printf("No original ADOFAI assets are included.\n\n");
        printf("Next: path animation, music,\n");
        printf("level files, and calibration.\n");

        gfxFlushBuffers();
        gfxSwapBuffers();
        gspWaitForVBlank();
    }

    gfxExit();
    return 0;
}
